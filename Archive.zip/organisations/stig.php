<h3>S.T.I.G (Sainte Trinité Inquisitrice de la Guerre)</h3>
<hr>
<p>Alliance des prêtres et paladins des dieux Tempus (champs de bataille), Tyr (sacrifice) et Torm (justice) dont le but est d'éradiquer le mal du monde, notamment en détruisant les morts-vivants et les démons.</p>
