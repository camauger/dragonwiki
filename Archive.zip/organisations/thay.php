<h3>Mages Rouges de Thay</h3>
<hr>
<p>Les Magiciens Rouges de Thay sont des lanceurs de sorts notoires et maléfiques qui règnent sur la région inhospitalière mais cependant très habitée de Thay. Esclavagistes, démonistes et expérimentateurs, les Sorciers Rouges sont extrêmement craints. Ils essaient constamment de conquérir les territoires voisins.</p>
<p>Les Magiciens Rouges sont dirigés par les huit Zulkirs, un par école de magie, eux-mêmes dirigés par Szass Tam, puissant archimage et liche.</p></p>
