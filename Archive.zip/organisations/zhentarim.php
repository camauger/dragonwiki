<h3>Zhentarim</h3>
<hr>
<p>le Zhentarim est une organisation sinistre visant à exploiter toutes les ressources du monde à ses propres fins. Étant à la base une société secrète, le Zhentarim a ouvertement opéré dans la région de la Mer de Lune, particulièrement autour de Château-Zhentil, sa base d'opérations. Le Zhentarim est actuellement dirigé par Fzoul Chembryl, Élu de Baine et Grand Seigneur du Zhentarim.
</p>
