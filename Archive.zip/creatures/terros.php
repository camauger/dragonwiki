<h3>Terros</h3>
<hr>
<p>À première vue, le Terro ressemble à un homme-lézard ou un saurien, mais il est beaucoup plus grand (10 pieds) et plus maigre et possède une crète allongée comme celle des ptéranodons. Ses écailles sont lisses et fines, ressemblant beaucoup à celles d'un serpent, de couleur allant du vert forêt aux tons clairs. Ses bras et jambes sont minces et longs, et ses mains et pieds portent des griffes acérées. Il est doté de membranes qui lui permettent de voler (son envergure peut atteindre 20 pieds).</p>
