<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="dragonwiki.css">
  <link href="https://fonts.googleapis.com/css?family=Eagle+Lake|Goudy+Bookletter+1911|Open+Sans|Raleway" rel="stylesheet">


  <title><?php echo $title; ?></title>
  <meta type="description" content="<?php echo $description; ?>">
</head>

<body>
  <?php
  include './nav.php'
  ?>
<?php
include './header.php'
?>
<div class="banner <?php echo $banner; ?>">

</div>
