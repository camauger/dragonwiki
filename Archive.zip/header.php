<header>
  <nav>
    <ul>
      <li>
        <a href="../sessions.php">Sessions</a>
      </li>
      <li>
<a href="../personnages.php">Personnages</a>
      </li>
      <li>
<a href="#">Lieux</a>
      </li>
      <li>
<a href="../organisations.php">Organisations</a>
      </li>
      <li>
<a href="../heros.php">Héros</a>
      </li>
    </ul>
  </nav>
  <h1>Le Tombeau de l'Annihilation</h1>
</header>
