

<header class="mainheader">

  <a class="maintitle" href="index.php">
  <h1>Le Tombeau de l'Annihilation</h1>
  </a>

</header>
