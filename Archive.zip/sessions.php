<!DOCTYPE html>

<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="dragonwiki.css">
    <link href="https://fonts.googleapis.com/css?family=Eagle+Lake|Goudy+Bookletter+1911|Open+Sans|Raleway" rel="stylesheet">


    <title></title>
  </head>
  <body>
<?php
include './header.php'
?>
<div class="banner tombofannihilation">

</div>
<main>
<div class="wrapper">


<div class="grid">
  <a href="./sessions/session1.php">
    <h3>Session 1</h3>
<h2>Gloradan</h2>
</a>
</div>

<div class="grid">
  <a href="./sessions/session2.php">
    <h3>Session 2</h3>
  <h2>Le Bois des Fées</h2>
  </a>
</div>

<div class="grid">
  <a href="sessions/session3.php">
    <h3>Session 3</h3>
  <h2>La Fin de l'Enfance</h2>
  </a>
</div>
<div class="grid">
  <a href="sessions/session4.php">
    <h3>Session 4</h3>
  <h2>La Colère du Dragon Tortue</h2>
  </a>
</div>

<div class="grid">
  <a href="sessions/session5.php">
    <h3>Session 5</h3>
  <h2>Nyanzaru</h2>
  </a>
</div>

</div>
</main>


<footer>
<?php
include 'footer.php' ?>
</footer>

</body>
</html>
