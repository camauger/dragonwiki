
<?php
  $title = "le titre de la page"; // Titre de la page
  $description = "la description de la page"; // Description de la page
  $banner = "tombofannihilation"; // Nom de l'image utilisée pour la bannière de la page
 ?>

<?php
include './head.php'
?>
<div class="wrapper">

<main>


<div class="grid">
  <a href="./sessions/session1.php">
    <h3>Session 1</h3>
<h2>Gloradan</h2>
</a>
</div>

<div class="grid">
  <a href="./sessions/session2.php">
    <h3>Session 2</h3>
  <h2>Le Bois des Fées</h2>
  </a>
</div>

<div class="grid">
  <a href="sessions/session3.php">
    <h3>Session 3</h3>
  <h2>La Fin de l'Enfance</h2>
  </a>
</div>
<div class="grid">
  <a href="sessions/session4.php">
    <h3>Session 4</h3>
  <h2>La Colère du Dragon Tortue</h2>
  </a>
</div>

<div class="grid">
  <a href="sessions/session5.php">
    <h3>Session 5</h3>
  <h2>Nyanzaru</h2>
  </a>
</div>

<div class="grid">
  <a href="sessions/session6.php">
    <h3>Session 6</h3>
  <h2>L'assaut des morts-vivants</h2>
  </a>
</div>

<div class="grid">
  <a href="sessions/session7.php">
    <h3>Session 7</h3>
  <h2>Le Triomphe</h2>
  </a>
</div>

<div class="grid">
  <a href="sessions/session8.php">
    <h3>Session 8</h3>
  <h2>Le Doigt de Feu</h2>
  </a>
</div>

<div class="grid">
  <a href="sessions/session9.php">
    <h3>Session 9</h3>
  <h2>Dungrunglung</h2>
  </a>
</div>

</main>
</div>

<?php
include 'footer.php' ?>
