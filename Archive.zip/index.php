<!DOCTYPE html>

<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="dragonwiki.css">
    <link href="https://fonts.googleapis.com/css?family=Goudy+Bookletter+1911" rel="stylesheet">

    <title></title>
  </head>
  <body>
<?php
include 'header.php'
?>

<main>

<div class="grid">
  <a href="sessions.php">
<h2>Sessions</h2>
</a>
</div>

<div class="grid">
    <a href="#">
  <h2>Personnages</h2>
  </a>
</div>

<div class="grid">
    <a href="#">
  <h2>Lieux</h2>
  </a>
</div>
<div class="grid">
    <a href="#">
  <h2>Organisations</h2>
  </a>
</div>


</main>



<?php
include 'footer.php' ?>


</body>
</html>
