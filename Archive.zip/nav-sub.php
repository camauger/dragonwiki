<div class="wrapper">
<nav>
  <ul>
      <a href="../sessions.php"><li>Sessions</li></a>
      <a href="../personnages.php"><li>Personnages</li></a>
      <a href="../lieux.php"><li>Lieux</li></a>
      <a href="../organisations.php"><li>Organisations</li></a>
      <a href="../heros.php"><li>Héros</li></a>
  </ul>
</nav>
  </div>
