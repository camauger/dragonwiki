
<footer>
  <div class="wrapper">

<nav>

      <div class="">
        <a href="../sessions.php">Sessions</a>
      </div>

      <div class="">
        <a href="../personnages.php">Personnages</a>
      </div>

<div class="">
  <a href="#">Lieux</a>
</div>

<div class="">
  <a href="#">Organisations</a>
</div>

<div class="">
  <a href="../heros.php">Héros</a>
</div>

</nav>

</div>
</footer>
