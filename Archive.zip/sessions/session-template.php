<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../dragonwiki.css">
    <link href="https://fonts.googleapis.com/css?family=Eagle+Lake|Goudy+Bookletter+1911|Open+Sans|Raleway" rel="stylesheet">
    <title></title>
  </head>
  <body>

<?php include "../header.php"; ?>

<div class="wrapper">

<main class="session">
<div class="">
<p style="font-size: 24px;">
Bonjour Félixe
</p>


<h2></h2>
<h4></h4>
<p></p>
 </main>
<aside class="">

</aside>
</div>
</body>
</html>
