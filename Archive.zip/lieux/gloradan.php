<h3>À propos de Gloradan</h3>
<hr>
<p>Gloradan est avant tout la forteresse du puissant archimage Dwinbar. Le village s’est progressivement formé autour de la forteresse. On y trouve des artisans, des érudits, des mercenaires et des paysans de toutes les races. Environ 500 habitants sont rassemblés autour de la forteresse de Gloradan. Il y a également quelques habitations et hameaux avoisinants.
La forteresse est située dans un paysage montagneux, rude, un peu à l’écart de la civilisation proprement dite. Il n’y a pas de grandes routes commerciales qui mènent à Gloradan, mais des voyageurs de partout dans le monde viennent régulièrement pour consulter les sages, faire fabriquer des oeuvres d’art rares ou faire halte avant d’entrer dans la Désolation avoisinante (territoire hostile peuplé de Géants et d’Orcs).
</p>
