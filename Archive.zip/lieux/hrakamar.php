<h3>Hrakamar</h3>
<hr>
<p>Forge sacrée des Nains Albinos de Chult, elle a été envahie par des lézards de feu et des salamandres.</p>
