<h3>Mezro</h3>
<hr>
<p>La cité circulaire de Mezro était autrefois la plus grande zone civilisée de Chult. La cité était un refuge sûr pour les explorateurs qui avaient subi la colère de la jungle et en une cité sainte aux yeux des tribus Chultaines. Tout individu violant la loi se voyait tatouer un triangle bleu sur le front puis être exilé. Les immortels baras d'Ubtao, des Élus semblables à des paladins, dirigeaient Mezro et la protégeaient des dangers. Au centre de la ville trônait le temple d'Ubtao et la cité possédait son propre collège de magie. La cité est aujourd'hui en ruines.</p>
