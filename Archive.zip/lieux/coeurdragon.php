<h3>Mine de Coeur-Dragon</h3>
<hr>
<p>Ancienne mine opérée par les Nains, elle a été prise d'assaut par un dragon rouge.</p>
