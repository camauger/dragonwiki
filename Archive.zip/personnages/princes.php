
<h3>Les Princes Marchands de Nyanzaru</h3>
<hr>
<p>Sept princes marchands, tous Chultans, gouvernent Nyanzaru, chacun ayant un vote. Ce sont les sept personnes les plus riches de la ville. Leur siège de gouvernement est le Trône d'Or, un ancien palais royal amnien qui surplombe la baie. </p>
<p>Les sept princes marchands actuels sont : Ekene-Afa (armes, boucliers, chariots, selles), Ifan Talro’a (bêtes et dressage), Jessamine (plantes, poisons), Jobal (guides, mercenaires), Kwayothé (vins, parfums, huiles), Wakanga O’tamu (magie) et Zhanthi (bijoux et pierres précieuses, vêtements, armures).</p>
