<h3>Fuk</h3>
<hr>
<p>Capitaine du Triomphe. Gnome de pierre de Lantan. Fume la pipe. Pas bavard.
</p>
