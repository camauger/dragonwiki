<h3>Ubtao</h3>
<hr>
<p>Il y a de cela des millénaires, la divinité Ubtao créa les jungles de Chult et les peupla de créatures. Puis la déesse construisit la ville de Mezro de ses propres mains laissa les sept Baras, des immortels, diriger la cité. Une partie de son essence divine, répandue sur terre, donna naissance à plusieurs esprits de la nature. Ubtao a délaissé Chult lorsque ses habitants ont tourné leur attention vers d'autres dieux.</p>
