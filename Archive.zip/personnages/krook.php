<h3>Krook</h3>
<hr>
<p>Prêtresse Grung à la peau rouge. Elle a cherché à obtenir l'aide des héros pour accomplir un rituel et surtout éviter la colère du roi Groark.</p>
