<h3>Dwinbar</h3>
<hr>
<p>L'archimage Dwinbar, gnome de pierre originaire de <a href="#">Lantan</a>, est un disciple de Bahamut et le maître du Pic des Mages de Laelith depuis de nombreuses années.
</p>
