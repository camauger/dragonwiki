<h3>Hurn le Chasseur</h3>
<hr>
<p>Hermite du Bois des Fées, ancien aventurier au passé mystérieux, virtuose de la scie musicale. Il a participé à la formation des héros et a remis son couteau de chasse à Solstice.</p>
