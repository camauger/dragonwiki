<h3>Malsum</h3>
<hr>
<p>Chevalier de Bahamut, Malsum dirigera un groupe de champions formé par Dwinbar. Ces héros finiront tués par erreur par d'autres héros, dans un tombeau d'Astufal... Malsum sera corrompu par Orcus et essaiera d'obtenir sa vengeance contre ceux qui l'ont vaincu. Mais ceci est une autre histoire...</p>
